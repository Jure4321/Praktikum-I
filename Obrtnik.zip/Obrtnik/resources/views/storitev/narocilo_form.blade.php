@extends('layouts.Lfooter')
@extends('layouts.Lmain')
@section('Title')
    <title>Moj Obrtnik | Iskanje</title>
@endsection
@section('Logo')
    Iskanje
@endsection

@section('Content')
<p>Da se naročiš na storitev <b>{{$storitev->naziv}}</b> vpiši svoje podatke!</p><br>
<form action="{{ route('naroci', $storitev->id) }}" method="POST" type="hidden" name="_token"   enctype="multipart/form-data">
{{ csrf_field() }}
    <input type="text" class="validate" name="ime" placeholder="Ime">
    <input type="text" class="validate" name="priimek" placeholder="Priimek">
    <input type="text" class="validate" name="email" placeholder="E-mail">
    <input type="text" class="validate" name="telefon" placeholder="Telefon">
    <text>Podatki o naročilu:</text><br>
    <input type="number" class="validate" name="okvirna_cena" placeholder="Okvirna cena">
    <text>Začetek: </text><input type="date" class="validate" name="datum_zacetka" value="2018-01-01">
    <text>konec: </text><input type="date" class="validate" name="datum_konca" value="2018-01-01">
    <textarea id="textarea1" class="materialize-textarea" name="komentar" placeholder="Komentar"></textarea>

    <button type="submit"class="waves-effect waves-light btn btn-large">Naroči</button>
</form>
@endsection