@extends('layouts.Lmain')

@selection('Title')
     <h1>Storitev<h1>
         {!! Form::open(['action' => 'PostsController@   ', 'method' => 'POST'])!!}
            <div class="form-group">
                {{Form::label('title', 'Naziv')}}
                {{Form::text('title', '', ['class' => 'form-control', 'placeholder' => 'Naziv'])}}
            </div>
            <div class="form-group">
                {{Form::label('body', 'Opis')}}
                {{Form::textarea('body', '', ['class' => 'form-control', 'placeholder' => 'Opis'])}}
            </div>
            {{Form::submit('Subm  it', ['class' => 'btn btn-primary'])}}
{!! Form::close ()!!}

@endselction