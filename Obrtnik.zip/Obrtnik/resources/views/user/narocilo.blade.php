@extends('layouts.Lmain')

@section('Title')
    <title>Moj Obrtnik | Profil</title>
@endsection
@section('Logo') 
{{ Auth::user()->name }}
@endsection

@section('Content')
@foreach($narocila as $narocilo) 


<div class="row" style="height:1em;"></div>

<div class="grey lighten-4 z-depth-2" style="padding:0.5em;width:80%;margin:auto">
        <div class="row" style="margin-bottom:0;">
            <div class="col s12 l6">
                <h5 class="green-text text-darken-3">Naziv storitve: <span style="color:black;">{{$narocilo->s_naziv}}</span></h5>
            </div>
            <div class="col s9 l3 offset-l3">
                    <h5 class="green-text text-darken-3">Številka naročila: <span style="color:black;">{{$narocilo->n_id}}</span></h5>
                </div>
        </div>
        <div class="divider">
    
        </div>
        <div class="row">
            <div class="col s12 l6">
                <h5 class="green-text text-darken-3">Naročnik: <span style="color:black;">{{$narocilo->ime}} {{$narocilo->priimek}}</span></h5>
            </div>
            
            <div class="col s12 l6">
                <h5 class="green-text text-darken-3">Email: <span style="color:black;">{{$narocilo->email}}</span></h5>
             </div>
            <div class="col s12 l6">
                <h5 class="green-text text-darken-3">Datum naročila: <span style="color:black;">{{$narocilo->created_at}}</span></h5>
             </div>
             <div class="col s12 l6 ">
                <h5 class="red-text text-darken-3">Datum pričetka dela: <span style="color:black;">{{$narocilo->datum_zacetka}}</span></h5>
            </div>
            <div class="col s12 l6 ">
                <h5 class="red-text text-darken-3">Datum konca dela: <span style="color:black;">{{$narocilo->datum_konca}}</span></h5>
            </div>
             
            
        </div>
        <div class="divider">
    
        </div>
        <div class="row">
                <div class="col s12 l6">
                    <h5 class="green-text text-darken-3">Telefon: <span style="color:black;">{{$narocilo->telefon}}</span></h5>
                </div>
                
                <div class="col s12 l6">
                    <h5 class="green-text text-darken-3">Okvirna cena: <span style="color:black;">{{$narocilo->okvirna_cena}}</span></h5>
                 </div>
                <div class="col s12 l12">
                    <h5 class="green-text text-darken-3">Komentar: </h5>
                    <p>{{$narocilo->komentar}}</p>
                 </div>
                 
                 
                
            </div>
            @if($narocilo->stanje==1)
            <div class="row">
                <div class="col s8 l10">
                <form action="{{ route('zavrni', $narocilo->n_id) }}" method="POST" type="hidden" name="_token">{{ csrf_field() }}
                <button type="submit" class=" btn btn-large btn-cancle waves-effect waves-light">
                    Zavrni
                 </button>
                </form>
                </div>
                <div class="col s2 l2">
                <form action="{{ route('odobri', $narocilo->n_id) }}" method="POST" type="hidden" name="_token">{{ csrf_field() }}
                <button type="submit" class=" btn btn-large  waves-effect waves-light">
                    Odobri
                 </button>
                </form>
                </div>
            </div>
            @endif

            @if($narocilo->stanje==2)
            <h2 style="background-color:MediumSeaGreen;">Sprejeto</h2>
            @endif

            @if($narocilo->stanje==3)
            <h2 style="background-color:Tomato;">Zavrnjeno</h2>
            @endif
    </div>



            
@endforeach
@endsection




