@extends('layouts.Lmain')

@section('Title')
    <title>Moj Obrtnik | Profil</title>
@endsection
@section('Logo') 
{{ Auth::user()->name }}
@endsection

@section('Content')

<form class="col s12" action="{{ route('razvrsti') }}" method="POST" type="hidden" name="_token" value="{{ csrf_token() }}">
    {{ csrf_field() }}
    <select name="razvrsti">
        <option id="dis" value="1">V čakanju</option>
        <option value="2">Sprejeta</option>
        <option value="3">Zavrnjena</option>
    </select>
    <button class="btn waves-effect waves-light btn-large btnMegaSearch" type="submit" name="action">Razvrsti </button>
</form>
@foreach($narocila as $narocilo) 
<div class="row" style="height:1em;"></div>

<div class="grey lighten-4 z-depth-2" style="padding:0.5em;width:80%;margin:auto">
    <div class="row" style="margin-bottom:0;">
        <div class="col s12 l6">
            <h5 class="green-text text-darken-3">Naziv storitve: <span style="color:black;">{{$narocilo->s_naziv}}</span></h5>
        </div>
        <div class="col s9 l3 offset-l3">
                <h5 class="green-text text-darken-3">Številka naročila: <span style="color:black;">{{$narocilo->n_id}}</span></h5>
            </div>
    </div>
    <div class="divider">

    </div>
    <div class="row">
        <div class="col s12 l12">
            <h5 class="green-text text-darken-3">Naročnik: <span style="color:black;">{{$narocilo->ime}} {{$narocilo->priimek}}</span></h5>
        </div>
        
        <div class="col s12 l12">
            <h5 class="green-text text-darken-3">Datum naročila: <span style="color:black;">{{$narocilo->created_at}}</span></h5>
         </div>
        <div class="col s12 l9">
            <h5 class="red-text text-darken-3">Datum roka: <span style="color:black;">{{$narocilo->datum_konca}}</span></h5>
         </div>
         <div class="col s12 l3">
                <a href="/narocila/{{$narocilo->n_id}}" class="waves-effect waves-light btn btn-large">Podrobnosti</a>
             </div>
        
    </div>
    

</div>          
@endforeach
@endsection




