@extends('layouts.Lmain')
<script>
        $(document).ready(function(){
              $('select').material_select();
            });
        </script>
<script type="text/javascript" src="https://code.jquery.com/jquery-3.2.1.min.js"></script>
<script src="https://cdnjs.cloudflare.com/aj    ax/libs/materialize/0.100.2/js/materialize.min.js"></script>