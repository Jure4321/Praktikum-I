<html>

<head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta http-equiv="X-UA-Compatible" content="ie=edge">
        <?php echo $__env->yieldContent('Title'); ?>
        <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
        <link href="https://fonts.googleapis.com/css?family=Bree+Serif|Francois+One|Indie+Flower|Kaushan+Script|Open+Sans|Roboto" rel="stylesheet">
        <link rel="stylesheet" type="text/css" href="<?php echo e(url('/css/materialize.min.css')); ?>" />
        <link rel="stylesheet" type="text/css" media="screen" href="<?php echo e(url('/css/styles.css')); ?>" />
</head>

<body class="green lighten-4">
    <header>
        <div class="navbar-fixed">
            <nav>
                <div class="green darken-3">
                        <div class="nav-wrapper">
                                <a class="brand-logo logo-razmik"><?php echo $__env->yieldContent('Logo'); ?></a>
                            <ul id="nav-mobile" class="left hide-on-med-and-down" style="margin-left:20em;">
                            <li><a href="<?php echo e(url('/')); ?>">Domov</a></li>
                            <li><a href="<?php echo e(url('/iskanje')); ?>">Iskanje</a></li>
                            </ul>
                            <ul id="nav-mobile" class="right hide-on-med-and-down" style="margin-right:2em;">
                                <li><a href="<?php echo e(url('/prijava')); ?>">Prijava</a></li>
                                <li><a href="<?php echo e(url('/registracija')); ?>">Registracija</a></li>
                              </ul>
                        </div>
                </div>
            </nav>
        </div>
                
    </header>
    <div class="container" id="logRegContainer">
            <?php echo $__env->yieldContent('Content'); ?>
    </div>
    
</body>
<script type="text/javascript" src="https://code.jquery.com/jquery-3.2.1.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/0.100.2/js/materialize.min.js"></script>

</html>