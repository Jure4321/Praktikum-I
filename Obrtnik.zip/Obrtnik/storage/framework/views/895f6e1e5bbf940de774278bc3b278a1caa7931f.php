<html>

<head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta http-equiv="X-UA-Compatible" content="ie=edge">
        <?php echo $__env->yieldContent('Title'); ?>
        <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
        <link href="https://fonts.googleapis.com/css?family=Bree+Serif|Francois+One|Indie+Flower|Kaushan+Script|Open+Sans|Roboto" rel="stylesheet">
        <link rel="stylesheet" type="text/css" href="<?php echo e(url('/css/materialize.min.css')); ?>" />
        <script src="<?php echo e(asset('js/app.js')); ?>" defer></script>
        

        
        <link rel="stylesheet" type="text/css" media="screen" href="<?php echo e(url('/css/styles.css')); ?>" />
</head>

<body class="white ">
    <header>
        <div class="navbar-fixed">
            <nav>
                <div class="green darken-3">
                        <div class="nav-wrapper">
                                <a class="brand-logo logo-razmik"><?php echo $__env->yieldContent('Logo'); ?></a>

                                <ul id="nav-mobile" class="left hide-on-med-and-down" style="margin-left:20em;">
                                <li><a href="<?php echo e(url('/')); ?>"><i class="material-icons left">home</i>Domov</a></li>
                                
                                <li><a href="<?php echo e(url('/iskanje')); ?>"><i class="material-icons left">search</i>Iskanje</a></li>
                                <?php if(auth()->guard()->guest()): ?>
                                <?php else: ?>
                                
                                <li style="border-left:1px solid white;"><a class="nav-link" href="<?php echo e(url('/storitve')); ?>"><i class="material-icons left">work</i><?php echo e(__('Moje Storitve')); ?></a></li>
                                <li><a class="nav-link" href="<?php echo e(route('n_index')); ?>"><i class="material-icons left">assignment</i><?php echo e(__('Naročila')); ?></a></li>
                                <?php endif; ?>
                            </ul>
                            <ul id="nav-mobile" class="right hide-on-med-and-down" style="margin-right:2em;">
                                <?php if(auth()->guard()->guest()): ?>
                                    
                                    <li><a class="nav-link" href="<?php echo e(route('login')); ?>"><i class="material-icons left">account_circle</i><?php echo e(__('Prijava')); ?></a></li>
                                    <li><a class="nav-link" href="<?php echo e(route('register')); ?>"><i class="material-icons left">add_circle_outline</i><?php echo e(__('Registracija')); ?></a></li>
                                <?php else: ?>
                                
                                    <li><a class="nav-link" href="<?php echo e(url('/profile')); ?>"><i class="material-icons left">account_box</i> <?php echo e(Auth::user()->name); ?> <span class="caret"></span></a></li>


                                    <li><a href="<?php echo e(route('logout')); ?>"
                                        onclick="event.preventDefault();
                                                      document.getElementById('logout-form').submit();"><i class="material-icons left">arrow_forward</i>
                                         <?php echo e(__('Logout')); ?>

                                     </a>
                         
                                     <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                                         <?php echo csrf_field(); ?>
                                     </form></li>
                                   
                                <?php endif; ?>
                              </ul>
                              
                        </div>
                </div>
            </nav>
        </div>
                
    </header>
    <?php echo $__env->yieldContent('Slika'); ?>
    <div class="container white" id="mainContainer" style="min-height:42.7em;">
        <?php echo $__env->yieldContent('Content'); ?>
    </div>
</body>
<?php echo $__env->yieldContent('Footer'); ?>
<script type="text/javascript" src="https://code.jquery.com/jquery-3.2.1.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/0.100.2/js/materialize.min.js"></script>
    <script>

(function($){
  $(function(){

     $('select').material_select();
  }); })(jQuery); 
    </script>


</html>

