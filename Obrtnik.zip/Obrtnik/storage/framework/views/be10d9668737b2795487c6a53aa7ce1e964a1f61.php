<?php $__env->startSection('Title'); ?>
    <title>Moj Obrtnik | Iskanje</title>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('Logo'); ?>
    Iskanje
<?php $__env->stopSection(); ?>

<?php $__env->startSection('Content'); ?>
<?php $__currentLoopData = $storitve; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $storitev): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <text>Naziv: </text><?php echo e($storitev->s_naziv); ?> <br>
    <text>Opis: </text><?php echo e($storitev->opis); ?> <br>
    <text>Naloženo: </text><?php echo e($storitev->created_at); ?> <br>
    <text>Obrtnik: </text><?php echo e($storitev->name); ?> <?php echo e($storitev->surname); ?><br>
    <text>Kategorija: </text><?php echo e($storitev->k_naziv); ?> <br>
    <text>Regija: </text><?php echo e($storitev->r_naziv); ?> <br>
    <text>Ocena: </text><?php echo e($storitev->avg_ocena); ?> <br>
    <img src="/storage/cover_images/<?php echo e($storitev->slika); ?>" style="width:10em;height:10em;"></img>

    <form action="<?php echo e(route('oceni', $storitev->id)); ?>" method="POST" type="hidden" name="_token">
    <?php echo e(csrf_field()); ?>

        <select name="ocena">
                    <option value="1">Slabo</option>
                    <option value="2">Zadovoljivo</option>
                    <option value="3">Odlično</option>
                    <option value="4">Perfektno</option>
        </select>
        <button type="submit"class="waves-effect waves-light btn btn-large">Oceni</button>
    </form>

    <a href='/storitve/<?php echo e($storitev->id); ?>/narocilo'>Naroci</a>
    <?php if($errors->any()): ?>
        <h4><?php echo e($errors->first()); ?></h4>
    <?php endif; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.Lmain', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('layouts.Lfooter', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>