<?php $__env->startSection('Title'); ?>
    <title>Moj Obrtnik | Registracija</title>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('Logo'); ?>
    Registracija
<?php $__env->stopSection(); ?>

<?php $__env->startSection('Content'); ?>
<div class="container">
    <div class="reg z-depth-5">
            <div class="container">
                    <?php echo MaterialForm::open(array('action' => 'RegController@Register', 'method'=>'POST')); ?>

                    <div style="height:3em;margin-top:1em;">
                        
                    </div>
                    <div class="row">
                        <div class="col s6">
                        <?php echo MaterialForm::text('Ime', 'ime'); ?> 
                        </div>
                        <div class="col s6">
                        <?php echo MaterialForm::text('Priimek', 'priimek'); ?> 
                        </div>
                    </div>
                    <div class="row">
                            <div class="col s6">
                            <?php echo MaterialForm::text('Uporabniško ime', 'uIme')->required(); ?> 
                            </div>
                            <div class="col s6">
                            <?php echo MaterialForm::email('Email', 'email')->addClass("validate")->required(); ?> 
                            </div>
                    </div>
                    <div class="row">
                            <div class="col s6">
                            <?php echo MaterialForm::password('Geslo', 'geslo')->required()->addClass("validate"); ?> 
                            </div>
                            <div class="col s6">
                            <?php echo MaterialForm::password('Ponovi Geslo', 'geslo2')->required()->addClass("validate"); ?> 
                            </div>
                    </div>
                    <div class="row">
                            <div class="col s6">
                            <?php echo MaterialForm::text('Davčna številka', 'davcna')->required(); ?> 
                            </div>
                            <div class="col s6">
                            <?php echo MaterialForm::text('Telefonska številka', 'telefon')->required(); ?> 
                            </div>
                    </div>
                    
                    <div class="row">
                            <div class="col s6">
                            
                            </div>
                            <div class="col s6">
                                <?php echo MaterialForm::submit("Registriraj")->addClass("btn btn-large btnReg"); ?>

                            </div>
                    </div>
                        
                    <?php echo MaterialForm::close(); ?>

                    
            </div>
            
    </div>  
</div>
<?php $__env->stopSection(); ?>
<!--



                <div class="row">
                        <div class="input-field col s6 ">
                            <input type="text"   name="ime">
                            <label >Ime</label>
                        </div>
                        <div class="input-field col s6 ">
                            <input type="text"   name="priimek">
                            <label >Priimek</label>
                        </div>
                    </div> 
                    <div class="row">
                        <div class="input-field col s5 ">
                            <input type="text" name="username">
                            <label >Uporabniško ime</label>
                        </div>
                        <div class="input-field col s7 ">
                            <input id="email" type="email" class="validate" name="email">
                            <label for="email" data-error="Vpišite pravilen email">Email</label>
                        </div>
                    </div> 
                    <div class="row">
                        <div class="input-field col s6 ">
                            <input type="password"   name="password">
                            <label >Geslo</label>
                        </div>
                        <div class="input-field col s6 ">
                            <input type="password"   name="passwordR">
                            <label >Ponovi Geslo</label>
                        </div>
                    </div>
                    <div class="row">
                            <div class="input-field col s6 ">
                                    <input type="text"   name="trr">
                                    <label >TRR</label>
                                </div>
                        <div class="input-field col s6" >
                                <button class="btn btn-large waves-effect waves-light" id="btnReg" type="submit" name="action">Registriraj
                                </button>
                        </div>
                    </div>
                -->
<?php echo $__env->make('layouts.LregLogin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>