<?php $__env->startSection('Logo'); ?>
Registracija
<?php $__env->stopSection(); ?>
<?php $__env->startSection('Content'); ?>
<div style="height:5em;"></div>
<div class="container">
        <form method="POST" action="<?php echo e(route('register')); ?>">
            <?php echo csrf_field(); ?>

            <div class="row">
                <div class="input-field">
                    <input id="name" type="text" class="<?php echo e($errors->has('name') ? ' is-invalid' : ''); ?>" name="name" value="<?php echo e(old('name')); ?>" required autofocus>
                    <label for="name"><?php echo e(__('Ime')); ?></label>
                    <?php if($errors->has('name')): ?>
                        <span class="invalid1">
                            <strong><?php echo e($errors->first('name')); ?></strong>
                        </span>
                    <?php endif; ?>
                </div>
            </div>
            <div class="row">
                    <div class="input-field">
                        <input id="surname" type="text" class="<?php echo e($errors->has('surname') ? ' is-invalid' : ''); ?>" name="surname" value="<?php echo e(old('surname')); ?>" required>
                        <label for="surname"><?php echo e(__('Priimek')); ?></label>
                        <?php if($errors->has('surname')): ?>
                            <span class="invalid1">
                                <strong><?php echo e($errors->first('surname')); ?></strong>
                            </span>
                        <?php endif; ?>
                    </div>
                </div>

            <div class="row">
                <div class="input-field">
                    <input id="email" type="email" class="<?php echo e($errors->has('email') ? ' is-invalid' : ''); ?>" name="email" value="<?php echo e(old('email')); ?>" required>
                    <label for="email"><?php echo e(__('E-Mail Naslov')); ?></label>
                    <?php if($errors->has('email')): ?>
                        <span class="invalid1">
                            <strong><?php echo e($errors->first('email')); ?></strong>
                        </span>
                    <?php endif; ?>
                </div>
            </div>

            <div class="row">
                <div class="input-field">
                    <input id="password" type="password" class="<?php echo e($errors->has('password') ? ' is-invalid' : ''); ?>" name="password" required>
                    <label for="password"><?php echo e(__('Geslo')); ?></label>
                    <?php if($errors->has('password')): ?>
                        <span class="invalid1">
                            <strong><?php echo e($errors->first('password')); ?></strong>
                        </span>
                    <?php endif; ?>
                </div>
            </div>

            <div class="row">
                <div class="input-field">
                    <input id="password-confirm" type="password" class="form-control" name="password_confirmation" required>
                    <label for="password-confirm"><?php echo e(__('Ponovi Geslo')); ?></label>
                </div>
            </div>

            <div class="row">
                    <div class="input-field">
                        <input id="davnca" type="text" class="<?php echo e($errors->has('davcna') ? ' is-invalid' : ''); ?>" name="davcna" value="<?php echo e(old('davcna')); ?>" required>
                        <label for="davcna"><?php echo e(__('Davčna številka')); ?></label>
                        <?php if($errors->has('davcna')): ?>
                            <span class="invalid1">
                                <strong><?php echo e($errors->first('davcna')); ?></strong>
                            </span>
                        <?php endif; ?>
                    </div>
                </div>

            <div class="row">
                    <div class="input-field">
                        <input id="telefon" type="text" class=" <?php echo e($errors->has('telefon') ? ' is-invalid' : ''); ?>" name="telefon" value="<?php echo e(old('telefon')); ?>" required>
                        <label for="telefon"><?php echo e(__('Telefon')); ?></label>
                        <?php if($errors->has('telefon')): ?>
                            <span class="invalid1">
                                <strong><?php echo e($errors->first('telefon')); ?></strong>
                            </span>
                        <?php endif; ?>
                    </div>
                </div>

            <div class="row">
                <div class="col s3 offset-s9">
                    <button type="submit" class="btn btn-large btnReg"><i class="material-icons left">check</i>
                        <?php echo e(__('Registriraj se')); ?>

                    </button>
                </div>
            </div>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.Lmain', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>